-----------------------
-- Suster Elena-Roxana
-- 11.10.2020
-----------------------
-- Edit the lines above with your name and the submission date.

module Solutions exposing (..)
-- ex 1.2.1

type Face = Two | Three | Four | Five | Six | Seven | Eight | Nine | Ten | Queen | King | Ace | Jack
type Suit = Clubs | Diamond | Heart | Spades
type Card = Card Face Suit

-- ex 1.2.2

faceToString : Face -> String
faceToString  f =
    case f of
        Two -> "Two"
        Three -> "Three"
        Four ->"Four"
        Five -> "Five"
        Six -> "Six"
        Seven -> "Seven"
        Eight -> "Eight"
        Nine -> "Nine"
        Ten -> "Ten"
        Queen -> "Queen"
        King -> "King"
        Ace -> "Ace"
        _ -> "Jack"


suitToString: Suit -> String
suitToString s =
    case s of
        Clubs -> "Clubs"
        Diamond -> "Diamond"
        Heart -> "Heart"
        Spades -> "Spades"
cardToString: Card -> String
cardToString (Card f s)=
    faceToString(f) ++ " of " ++ suitToString(s)

-- ex 1.2.3

type alias Point = {x : Float, y : Float}
type alias Segment = {p1 : Point, p2: Point}

findMin a b = if a<b then a else b
findMax a b = if a>b then a else b
calcRamp s1 =
    (s1.p2.y - s1.p1.y) / (s1.p2.x - s1.p1.x)

findPoint: Segment -> Segment -> String
findPoint s1 s2 =
    let
        m1 = calcRamp s1
        m2 = calcRamp s2
        i1 = (((s1.p1.x * s1.p2.y - s1.p1.y * s1.p2.x) * (s2.p1.x - s2.p2.x) - (s1.p1.x - s2.p2.x) * (s2.p1.x * s2.p2.y - s2.p1.y * s2.p2.x)) / ((s1.p1.x - s1.p2.x) * (s2.p1.y - s2.p2.y) - (s1.p1.y - s1.p2.y)* (s2.p1.x - s2.p2.x)))
        i2=  (((s1.p1.x * s1.p2.y- s1.p1.y * s1.p2.x) * (s2.p1.y - s2.p2.y) - (s1.p1.y - s1.p2.y) * (s2.p1.x * s2.p2.y - s2.p1.y * s2.p2.x)) / ((s1.p1.x - s1.p2.x) * (s2.p1.y - s2.p2.y) - (s1.p1.y - s1.p2.y) * (s2.p1.x - s2.p2.x)))

     in
     if m1 == m2 then " The lines are parallel"
     else
     if (i1 < (findMin s1.p1.x s1.p2.x) || i1 > (findMax s1.p1.x s1.p1.x)) then
     "Not an intersection"
     else
     if(i1 < (findMin s2.p1.x s2.p2.x) || i1 > (findMax s2.p1.x s2.p2.x)) then
     "Not an intersection"
     else
     if(i2< (findMin s1.p1.y s1.p2.y) || i2 > (findMax s1.p1.y s1.p2.y)) then
     "Not an intersection point"
     else
     if(i1 <(findMin s2.p1.y s2.p2.y) || i2 > (findMax s2.p1.y s2.p2.y)) then
     "Not an intersection point"
     else
     "The intersection point is: " ++ String.fromFloat(i1) ++ " " ++ String.fromFloat(i2)

-- ex 1.2.4

trailingZeroes : Float -> Int
trailingZeroes nr =
    let
        helpFunction : Float -> Float -> Int
        helpFunction n i =
            if n/i < 1 then 0
            else
            floor(n/i) + helpFunction n (i*5)
     in
      helpFunction nr 5



































